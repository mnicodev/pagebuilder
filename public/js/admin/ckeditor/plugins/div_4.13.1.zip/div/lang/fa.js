/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'fa', {
	IdInputLabel: 'شناسه',
	advisoryTitleInputLabel: 'عنوان مشاوره',
	cssClassInputLabel: 'کلاس​های شیوه​نامه',
	edit: 'ویرایش Div',
	inlineStyleInputLabel: 'سبک درون​خطی(Inline Style)',
	langDirLTRLabel: 'چپ به راست (LTR)',
	langDirLabel: 'جهت نوشتاری زبان',
	langDirRTLLabel: 'راست به چپ (RTL)',
	languageCodeInputLabel: ' کد زبان',
	remove: 'حذف Div',
	styleSelectLabel: 'سبک',
	title: 'ایجاد یک محل DIV',
	toolbar: 'ایجاد یک محل DIV'
} );
