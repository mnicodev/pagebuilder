/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'sr', {
	IdInputLabel: 'Ид',
	advisoryTitleInputLabel: 'Савет',
	cssClassInputLabel: 'ЦСС класе',
	edit: 'ДИВ уређивач',
	inlineStyleInputLabel: 'Инлине стил',
	langDirLTRLabel: 'С лева на десно (LTR)',
	langDirLabel: 'Смер језика',
	langDirRTLLabel: 'С десна на лево (RTL)',
	languageCodeInputLabel: 'Код језика',
	remove: 'Уклони Див',
	styleSelectLabel: 'Стил',
	title: 'Креирање ДИВ спремишта',
	toolbar: 'Креирање ДИВ спремишта'
} );
