/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'eu', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Aholkatutako izenburua',
	cssClassInputLabel: 'Estilo-orriko klaseak',
	edit: 'Editatu Div-a',
	inlineStyleInputLabel: 'Lineako estiloa',
	langDirLTRLabel: 'Ezkerretik eskuinera (LTR)',
	langDirLabel: 'Hizkuntzaren norabidea',
	langDirRTLLabel: 'Eskuinetik ezkerrera (RTL)',
	languageCodeInputLabel: 'Hizkuntzaren kodea',
	remove: 'Kendu Div-a',
	styleSelectLabel: 'Estiloa',
	title: 'Sortu Div edukiontzia',
	toolbar: 'Sortu Div edukiontzia'
} );
