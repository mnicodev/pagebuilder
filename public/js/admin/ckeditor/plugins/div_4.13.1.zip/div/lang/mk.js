/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'mk', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Advisory Title', // MISSING
	cssClassInputLabel: 'Stylesheet Classes', // MISSING
	edit: 'Edit Div', // MISSING
	inlineStyleInputLabel: 'Inline Style', // MISSING
	langDirLTRLabel: 'Лево кон десно',
	langDirLabel: 'Насока на јазик',
	langDirRTLLabel: 'Десно кон лево',
	languageCodeInputLabel: ' Language Code', // MISSING
	remove: 'Remove Div', // MISSING
	styleSelectLabel: 'Стил',
	title: 'Create Div Container', // MISSING
	toolbar: 'Create Div Container' // MISSING
} );
