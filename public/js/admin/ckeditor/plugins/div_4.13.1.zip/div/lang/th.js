/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'th', {
	IdInputLabel: 'ไอดี',
	advisoryTitleInputLabel: 'คำเกริ่นนำ',
	cssClassInputLabel: 'คลาสของไฟล์กำหนดลักษณะการแสดงผล',
	edit: 'แก้ไข Div',
	inlineStyleInputLabel: 'Inline Style', // MISSING
	langDirLTRLabel: 'จากซ้ายไปขวา (LTR)',
	langDirLabel: 'การเขียน-อ่านภาษา',
	langDirRTLLabel: 'จากขวามาซ้าย (RTL)',
	languageCodeInputLabel: 'รหัสภาษา',
	remove: 'ลบ Div',
	styleSelectLabel: 'ลักษณะการแสดงผล',
	title: 'Create Div Container', // MISSING
	toolbar: 'Create Div Container' // MISSING
} );
