/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'div', 'ru', {
	IdInputLabel: 'Идентификатор',
	advisoryTitleInputLabel: 'Заголовок',
	cssClassInputLabel: 'Классы CSS',
	edit: 'Редактировать контейнер',
	inlineStyleInputLabel: 'Стиль элемента',
	langDirLTRLabel: 'Слева направо (LTR)',
	langDirLabel: 'Направление текста',
	langDirRTLLabel: 'Справа налево (RTL)',
	languageCodeInputLabel: 'Код языка',
	remove: 'Удалить контейнер',
	styleSelectLabel: 'Стиль',
	title: 'Создать Div-контейнер',
	toolbar: 'Создать Div-контейнер'
} );
